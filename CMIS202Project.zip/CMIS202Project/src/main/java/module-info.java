module com.example.cmis202project {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.cmis202project to javafx.fxml;
    exports com.example.cmis202project;
}